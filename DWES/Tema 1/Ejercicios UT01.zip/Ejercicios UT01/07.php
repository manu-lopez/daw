<!-- Ejercicio 07

Crea las variables $nombre, $direccion y $telefono y asígnales los valores adecuados. Muestra los valores por pantalla de tal forma que el resultado sea el mismo que el del ejercicio 2. -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
</head>

<body>
  <?php
  $nombre = "Manuel";
  $direccion = "Lorem, ipsum dolor.";
  $telefono = "Lorem, ipsum dolor.";

  echo "<p> Nombre: $nombre";
  echo "<p> Dirección: $direccion";
  echo "<p> Teléfono: $telefono";
  ?>
</body>

</html>